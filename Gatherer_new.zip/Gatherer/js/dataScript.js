(function() {
// Initialize Firebase
	var config = {
		apiKey: "AIzaSyATop3jo74C4FrfLBQaHxaZpM2Tlg8TPAQ",
		authDomain: "test-927de.firebaseapp.com",
		databaseURL: "https://test-927de.firebaseio.com",
		projectId: "test-927de",
		storageBucket: "test-927de.appspot.com",
		messagingSenderId: "813887042760" 
	};
	firebase.initializeApp(config);
    var uid;
    
    firebase.auth().onAuthStateChanged(function(user) {
		if (user) {
			console.log(user.uid);
			uid = user.uid;
		return;
		} else {
			alert('You must be signed in!');
			window.location.href = "login-register.html";
		}
    });
	
    // Get button elements
	var upload = document.getElementById('upload');
	
    upload.addEventListener('click', function(){
		
		var test = true;

		// Here the tags etc get uploaded to the database

		var database = firebase.database();
		var ref = database.ref('cards/'+uid);
    
		//var databaseRef = firebase.database().ref('cards'.uid);

		var title = document.getElementById('title').value;
      
		var tag = null; 
		var inputElements = document.getElementsByClassName('tags');
		for(var i=0; inputElements[i]; ++i){                //this loop fetches the value of the checked box
			if(inputElements[i].checked){
				tag = inputElements[i].value;
				break;
			}
		}
		if(tag == null){
			test = false;
		}
		
		var price = 'undefined';
		var action = null; 
		var inputElements = document.getElementsByClassName('aktion');
		for(var i=0; inputElements[i]; ++i){
			if(inputElements[i].checked){
				action = inputElements[i].value;
				break;
			}
		}
		if(action == null){
			test = false;
		}
		else if(action == "Verkaufen"){
			price = document.getElementById('price').value;
			document.getElementById('test-result').innerHTML = "<p class'text-center'>Preis:"+price+"</p>";
			
		}
		
	  
		var imagetype = document.getElementById('foto').files[0];
		var imagename = imagetype.name;
	  
		//document.getElementById('test-result').innerHTML = "<p class'text-center'>Title: "+title+" tag: "+tag+" action: "+action+" imagename: "+imagename+" submit: "+test+"</p>";
        
		if(test == true){
			var data={
        
				imagename: imagename,
				title: title,
				tag: tag,
				aktion: action,
				price: price
			}
			console.log(data);
      
			ref.push(data);
			ref.on('child_added', function(snapshot) {
				var message = snapshot.val();
				var id = snapshot.key;

				// Image Upload to Storage
      
				// Get file
				var  file = document.getElementById('foto').files[0];
				console.log('file:'+file);


				// Create a storage Ref
				var spaceRef = firebase.storage().ref('cards/'+uid+'/'+id+'/'+file.name);
	 

				// Upload file
				var task = spaceRef.put(file);
	

				task.on('state_changed', 
					function error(err){
						console.log(err);
					},
					function completed(){
						console.log('Success!');
        
					}
				);
	  
				//document.getElementById('test-result').innerHTML = "<p class'text-center'>Deine Karte wurde hochgeladen!</p>";
			});
		}
		else{
			document.getElementById('test-result').innerHTML = "<p class'text-center'>Es gab einen Fehler!</p>";
		}
      
    /*var updates = {};
      updates['/users/' + uid] = data; 
      firebase.database().ref().update(updates);*/


      
      
      
    });
})();