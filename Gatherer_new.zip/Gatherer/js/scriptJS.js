function hide(input){
	document.getElementById(input).style.visibility='hidden';
	document.getElementById(input).style.position='absolute';
}

function show(input){
	document.getElementById(input).style.visibility='visible';
	document.getElementById(input).style.position='static';
}

