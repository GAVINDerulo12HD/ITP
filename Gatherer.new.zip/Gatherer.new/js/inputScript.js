
var config = {
		apiKey: "AIzaSyATop3jo74C4FrfLBQaHxaZpM2Tlg8TPAQ",
		authDomain: "test-927de.firebaseapp.com",
		databaseURL: "https://test-927de.firebaseio.com",
		projectId: "test-927de",
		storageBucket: "test-927de.appspot.com",
		messagingSenderId: "813887042760" 
	};
		firebase.initializeApp(config);
		var database = firebase.database();

var refInp = database.ref('input/');

var searchSubmit = document.getElementById('searchSubmit');
searchSubmit.addEventListener('click', function(){
var inputer = document.getElementById('searcher').value;
var data = inputer;
refInp.set(data);
window.location.href = "Kaufen.html";
});