function hide(input){
	document.getElementById(input).style.visibility='hidden';
}

function show(input){
	document.getElementById(input).style.visibility='visible';
}
function checkEingaben(){
	var verkaufen = document.getElementById("verkaufen").checked;
	var preis = document.getElementById("price").value;
	if(!checkPrice(preis) && verkaufen==true){
		alert("Kein gültiger Preis angegeben");
		return false;
	}
	else{
		return true;
	}
}
function checkPrice(preis){
	var validation = new RegExp("^[0-9]+[,\.]{1}[0-9]{2}$");
	return validation.test(preis);
}