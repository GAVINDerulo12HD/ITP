
var stringArray = [];
var checkForCont = 0;
console.log("Counter0: "+checkForCont);
var determ = true;

function sleep(miliseconds) {
   var currentTime = new Date().getTime();

   while (currentTime + miliseconds >= new Date().getTime()) {
   }
};

function printer(stringCont){
		console.log("why");
		var leadsRef = firebase.database().ref('cards');
		
		//document.getElementById('card-container').innerHTML = "<p>leadsRef: " +leadsRef+ "</p>";
		
		leadsRef.on('value', function(snapshot) {
			
			snapshot.forEach(function(childSnapshot) {
				
				var uid = childSnapshot.key;
				//var countStrng = 0;
				childSnapshot.forEach(function(childChildSnapshot) {
					console.log("Counter: "+checkForCont);
					var id = childChildSnapshot.key;
					var newData = childChildSnapshot.val();
					var action = newData.aktion;
					var tag = newData.tag;
					

					var title = newData.title;
					var checker;

					var imagename = newData.imagename;
					for(var loop = 0; loop<stringCont.length; loop++){
						if((stringCont[loop] == title) || stringCont[loop] == tag ){
								checker = true;
								break;
						}
						checker = false;
					}
					console.log(checker);
					if(checker == true){
					if(action == "Verkaufen"){
						var price = newData.price;
						var storageRef = firebase.storage().ref();
						storageRef.child('cards/'+uid+'/'+id+'/'+imagename).getDownloadURL().then(function(url) {
							var div = document.createElement('div');
							div.setAttribute('class', 'container col-md-4 col-sm-6 col-xs-12');
							div.innerHTML = "<div class='karte text-center'><img src='"+url+"' class='img-responsive center-block'><h4>"+title+"</h4><p>Preis: "+price+"€</p></div>";
							document.getElementById('card-container').appendChild(div);
							
							

							
						}).catch(function(error) {

						});
						++checkForCont;
						console.log("Counter2: "+checkForCont);
					}
					else{
						var storageRef = firebase.storage().ref();
						storageRef.child('cards/'+uid+'/'+id+'/'+imagename).getDownloadURL().then(function(url) {
							var div = document.createElement('div');
							div.setAttribute('class', 'container col-md-4 col-sm-6 col-xs-12');
							div.innerHTML = "<div class='karte text-center'><img src='"+url+"' class='img-responsive center-block'><h4>"+title+"</h4><p>"+action+"</p></div>";
							document.getElementById('card-container').appendChild(div);
							
														
						}).catch(function(error) {

						});
						++checkForCont;
						console.log("Counter3: "+checkForCont);
					};
				};
					
				}); 
			});
		});
	};
function compaerer (sa1, sa2){
    // Compare two strings to see how similar they are.
    // Answer is returned as a value from 0 - 1
    // 1 indicates a perfect similarity (100%) while 0 indicates no similarity (0%)
    // Algorithm is set up to closely mimic the mathematical formula from
    // the article describing the algorithm, for clarity. 
    // Algorithm source site: http://www.catalysoft.com/articles/StrikeAMatch.html
    // (Most specifically the slightly cryptic variable names were written as such
    // to mirror the mathematical implementation on the source site)
    //
    // 2014-04-03
    // Found out that the algorithm is an implementation of the Sørensen–Dice coefficient [1]
    // [1] http://en.wikipedia.org/wiki/S%C3%B8rensen%E2%80%93Dice_coefficient
    //
    // The algorithm is an n-gram comparison of bigrams of characters in a string


    // for my purposes, comparison should not check case or whitespace
    var s1 = sa1.replace(/\s/g, "").toLowerCase();
    var s2 = sa2.replace(/\s/g, "").toLowerCase();
    //console.log(s1+" "+s2);
    function intersect(arr1, arr2) {
        // I didn't write this.  I'd like to come back sometime
        // and write my own intersection algorithm.  This one seems
        // clean and fast, though.  Going to try to find out where
        // I got it for attribution.  Not sure right now.
        var r = [], o = {}, l = arr2.length, i, v;
        for (i = 0; i < l; i++) {
            o[arr2[i]] = true;
        }
        l = arr1.length;
        for (i = 0; i < l; i++) {
            v = arr1[i];
            if (v in o) {
                r.push(v);
            }
        }
        //console.log(r);
        return r;
    }
    
    var pairs = function(s){
        // Get an array of all pairs of adjacent letters in a string
        var pairs = [];
        for(var i = 0; i < s.length - 1; i++){
            pairs[i] = s.slice(i, i+2);
        }
        return pairs;
    }    
    
    var similarity_num = 2 * intersect(pairs(s1), pairs(s2)).length;
    var similarity_den = pairs(s1).length + pairs(s2).length;
    var similarity = similarity_num / similarity_den;
    return similarity;
};




// Initialize Firebase
  var config = {
    apiKey: "AIzaSyATop3jo74C4FrfLBQaHxaZpM2Tlg8TPAQ",
    authDomain: "test-927de.firebaseapp.com",
    databaseURL: "https://test-927de.firebaseio.com",
    projectId: "test-927de",
    storageBucket: "test-927de.appspot.com",
    messagingSenderId: "813887042760" 
  };
    firebase.initializeApp(config);
    	
    	var leadsRefInp  = firebase.database().ref('input');
   		var checkers;
		leadsRefInp.on("value", function(snapshot){
		
		checkers = snapshot.val();
		console.log("Test: "+checkers);
		if(checkers!==null){
		document.getElementById("searcher").value = checkers;
		
		//document.getElementById("searchSubmit").click();
		determ = false;
		
		}
	
		});
	

    var uid;
	
    // Get button elements
	var getCards = document.getElementById('get-cards');
	
	

	
		var leadsRef = firebase.database().ref('cards');
		
		//document.getElementById('card-container').innerHTML = "<p>leadsRef: " +leadsRef+ "</p>";
		
		leadsRef.on('value', function(snapshot) {
			
			snapshot.forEach(function(childSnapshot) {
				console.log("PLS1");
				var uid = childSnapshot.key;
				var countStrng = 0;
				childSnapshot.forEach(function(childChildSnapshot) {
					
					var id = childChildSnapshot.key;
					var newData = childChildSnapshot.val();
					var action = newData.aktion;
					var tag = newData.tag;
					stringArray[countStrng] = tag;
					++countStrng;

					var title = newData.title;
					stringArray[countStrng] = title;
					var imagename = newData.imagename;
						if(determ==true){
					if(action == "Verkaufen"){
						var price = newData.price;
						var storageRef = firebase.storage().ref();
						storageRef.child('cards/'+uid+'/'+id+'/'+imagename).getDownloadURL().then(function(url) {
							var div = document.createElement('div');
							div.setAttribute('class', 'container col-md-4 col-sm-6 col-xs-12');
							div.innerHTML = "<div class='karte text-center'><img src='"+url+"' class='img-responsive center-block'><h4>"+title+"</h4><p>Preis: "+price+"€</p></div>";
							document.getElementById('card-container').appendChild(div);
						}).catch(function(error) {

						});
					}
					else{
						var storageRef = firebase.storage().ref();
						storageRef.child('cards/'+uid+'/'+id+'/'+imagename).getDownloadURL().then(function(url) {
							var div = document.createElement('div');
							div.setAttribute('class', 'container col-md-4 col-sm-6 col-xs-12');
							div.innerHTML = "<div class='karte text-center'><img src='"+url+"' class='img-responsive center-block'><h4>"+title+"</h4><p>"+action+"</p></div>";
							document.getElementById('card-container').appendChild(div);
						
						}).catch(function(error) {

						});
					}
				}


					++countStrng;
				
				}); 
			});
			if(determ==false){
				console.log("test1");
					document.getElementById("searchSubmit").click();
					console.log("test2");
					
				}
		});
		
		
	
	



document.getElementById("searchSubmit").onclick = function(){

	$("#card-container").empty();
	var sSimilarity = [];
	var sa1 = document.getElementById("searcher").value;
	
	console.log("OMG::: "+sa1);
	for(var loop = 0; loop<stringArray.length; loop++){
		sa2 = stringArray[loop];
		sSimilarity[loop] = compaerer(sa1, sa2);
 
};
var stringVal = [];
var stringCont = [];

for(var loop = 0; loop<sSimilarity.length; loop++){
	if(sSimilarity[loop]>0.3){
		console.log("lastHope");
		stringCont[loop] = stringArray[loop];
		//console.log(stringCont[loop]+"="+sSimilarity[loop]);
	}
	
}
printer(stringCont);


if(checkForCont==0){
	var div = document.createElement('div');
	div.setAttribute('class', 'container col-md-4 col-sm-6 col-xs-12');
	div.innerHTML = "<div style='color: black;' class='karte text-center center-block'><h2>No matching cards were found</h2></div>";
	document.getElementById('card-container').appendChild(div);
	console.log("Nothing!");
}
var delRef = firebase.database().ref('input');
delRef.remove();
checkForCont=0;




};


