 (function(){

 // Initialize Firebase
  var config = {
		apiKey: "AIzaSyATop3jo74C4FrfLBQaHxaZpM2Tlg8TPAQ",
		authDomain: "test-927de.firebaseapp.com",
		databaseURL: "https://test-927de.firebaseio.com",
		projectId: "test-927de",
		storageBucket: "test-927de.appspot.com",
		messagingSenderId: "813887042760"
	};
		firebase.initializeApp(config);
		
		var database = firebase.database();

		
		var ref = database.ref('users');
		var gulUsers = document.getElementById('gul_users_list');
		var databaseRef = firebase.database().ref('users');



		const txtEmail = document.getElementById('txtEmail');
		const txtPassword = document.getElementById('txtPassword');
		const btnSignUp = document.getElementById('btnSignUp');

		// Add signup event

		btnSignUp.addEventListener('click', e =>{
			//get email and password
			const email = txtEmail.value;
			const pass = txtPassword.value;
			const auth = firebase.auth();
			//Sign Up
			const promise = auth.createUserWithEmailAndPassword(email, pass);
			 promise
			 	.catch(e => console.log(e.message)).value;
		});

		// add a realtime listener
		firebase.auth().onAuthStateChanged(firebaseUser =>{
			if(firebaseUser){
				console.log(firebaseUser);
			}else{
				console.log('not logged in');
			}
		});

		

		
		/*function save_user(){
			
			//TODO: Check for real email and password
			var email = document.getElementById('email').value;
			var password = document.getElementById('pass').value;
			
			//var uid = firebase.database().ref().child('users').push.key;
			firebase.auth().createUserWithEmailAndPassword(email, password),
			promise.catch(e => console.log(e.message));
			/*var data={
				email: email, 
				id: id_name,
				password: pwd
			}
			console.log(email);
			console.log(data);
			ref.push(data);*/
			
	 	/*var updates = {};
			updates['/users/' + uid] = data; 
			firebase.database().ref().update(updates);*/
		}());

	
		
		
	