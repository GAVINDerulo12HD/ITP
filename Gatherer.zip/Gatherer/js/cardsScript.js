(function() {
// Initialize Firebase
  var config = {
    apiKey: "AIzaSyATop3jo74C4FrfLBQaHxaZpM2Tlg8TPAQ",
    authDomain: "test-927de.firebaseapp.com",
    databaseURL: "https://test-927de.firebaseio.com",
    projectId: "test-927de",
    storageBucket: "test-927de.appspot.com",
    messagingSenderId: "813887042760" 
  };
    firebase.initializeApp(config);
    var uid;
	
    // Get button elements
	var getCards = document.getElementById('get-cards');
	
	$(document).ready(function(){
	
		var leadsRef = firebase.database().ref('cards');
		
		//document.getElementById('card-container').innerHTML = "<p>leadsRef: " +leadsRef+ "</p>";
		
		leadsRef.on('value', function(snapshot) {
			
			snapshot.forEach(function(childSnapshot) {
				
				var uid = childSnapshot.key;
				
				childSnapshot.forEach(function(childChildSnapshot) {

					var id = childChildSnapshot.key;
					var newData = childChildSnapshot.val();
					var action = newData.aktion;
					var title = newData.title;
					var imagename = newData.imagename;
					
					var storageRef = firebase.storage().ref();
					storageRef.child('cards/'+uid+'/'+id+'/'+imagename).getDownloadURL().then(function(url) {
						var div = document.createElement('div');
						div.setAttribute('class', 'container col-md-4 col-sm-6 col-xs-12');
						div.innerHTML = "<div class='karte text-center'><img src='"+url+"' class='img-responsive center-block'><h4>"+title+"</h4><p>"+action+"</p></div>";
						document.getElementById('card-container').appendChild(div);
					
					}).catch(function(error) {

					});
				}); 
			});
		});
	});
})();