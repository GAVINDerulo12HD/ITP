function hide(input){
	document.getElementById(input).style.visibility='hidden';
	document.getElementById(input).style.position='absolute';
}

function show(input){
	document.getElementById(input).style.visibility='visible';
	document.getElementById(input).style.position='static';
}



var looger = document.getElementById("logger");
var logger_1 = document.getElementById("logger1");
firebase.auth().onAuthStateChanged(firebaseUser =>{
			if(firebaseUser){
				console.log(firebaseUser);
				logger_1.classList.remove('hide');
				logger.classList.add('hide');				
			}else{
				console.log('not logged in');
				logger.classList.remove('hide');
				logger_1.classList.add('hide');				
			}
});
logger_1.addEventListener('click', function(){
			firebase.auth().signOut();
});
