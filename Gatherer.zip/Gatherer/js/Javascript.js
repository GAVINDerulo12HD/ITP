 //Card-Gatherer-Javascript
 //https://blog.fossasia.org/set-up-firebase-to-upload-user-files/  ==>for file upload.js
 (function(){

 // Initialize Firebase
  var config = {
		apiKey: "AIzaSyATop3jo74C4FrfLBQaHxaZpM2Tlg8TPAQ",
		authDomain: "test-927de.firebaseapp.com",
		databaseURL: "https://test-927de.firebaseio.com",
		projectId: "test-927de",
		storageBucket: "test-927de.appspot.com",
		messagingSenderId: "813887042760"
	};
		firebase.initializeApp(config);
		
		var database = firebase.database();
		const auth = firebase.auth();

		
		var ref = database.ref('users');
		var gulUsers = document.getElementById('gul_users_list');
		var databaseRef = firebase.database().ref('users');



		var txtEmail = document.getElementById('txtEmail2');
		var txtPassword = document.getElementById('txtPassword2');
		var btnSignUp = document.getElementById('btnSignUp');

		// Add signup event

		btnSignUp.addEventListener('click', e =>{
			//get email and password
			var email = txtEmail.value;
			var pass = txtPassword.value;
			//Sign Up
			var promise = auth.createUserWithEmailAndPassword(email, pass);
			 promise.catch(e => console.log(e.message));
			 promise.catch(e=> alert(e.message));

			// For Email verification, not yet ready
			/*var user = firebase.auth().currentUser;  

			user.sendEmailVerification().then(function() {
  				// Email sent.
			}).catch(function(error) {
  				// An error happened.
			});*/
		});

		// add a realtime listener
		firebase.auth().onAuthStateChanged(firebaseUser =>{
			if(firebaseUser){
				console.log(firebaseUser);
				btnLogout.classList.remove('hide');		
			}else{
				console.log('not logged in');
				btnLogout.classList.add('hide');			
			}
		});
		

		var txtEmail2 = document.getElementById('txtEmail2');
		var txtPassword2 = document.getElementById('txtPassword2');
		var btnLogin = document.getElementById('btnLogin');

		btnLogin.addEventListener('click', e =>{
			//get email and password
			var email = txtEmail2.value;
			var pass = txtPassword2.value;
			var auth = firebase.auth();
			//Signin
			console.log(email);
			var promise = auth.signInWithEmailAndPassword(email, pass);
			 promise
			 	.catch(e => console.log(e.message)).value;

		});

		btnLogout.addEventListener('click', e =>{
			firebase.auth().signOut();

		});

		

		
		/*function save_user(){
			
			//TODO: Check for real email and password
			var email = document.getElementById('email').value;
			var password = document.getElementById('pass').value;
			
			//var uid = firebase.database().ref().child('users').push.key;
			firebase.auth().createUserWithEmailAndPassword(email, password),
			promise.catch(e => console.log(e.message));
			/*var data={
				email: email, 
				id: id_name,
				password: pwd
			}
			console.log(email);
			console.log(data);
			ref.push(data);*/
			
	 	/*var updates = {};
			updates['/users/' + uid] = data; 
			firebase.database().ref().update(updates);*/
		}());

	
		
		
	